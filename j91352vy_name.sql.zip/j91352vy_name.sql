-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Фев 28 2021 г., 12:51
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `j91352vy_name`
--

-- --------------------------------------------------------

--
-- Структура таблицы `route`
--
-- Создание: Янв 23 2021 г., 18:01
-- Последнее обновление: Янв 24 2021 г., 07:23
--

DROP TABLE IF EXISTS `route`;
CREATE TABLE `route` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `route`
--

INSERT INTO `route` (`id`, `name`) VALUES
(1, '8 микрорайон'),
(2, '13 микрорайон'),
(3, '12 микрорайон'),
(4, 'Универмаг'),
(5, 'ХГУ'),
(6, 'Ёва'),
(7, 'Панчшанбе'),
(8, '31 микрорайон'),
(9, 'Сомон бозор');

-- --------------------------------------------------------

--
-- Структура таблицы `transport`
--
-- Создание: Янв 24 2021 г., 07:29
-- Последнее обновление: Янв 25 2021 г., 16:44
--

DROP TABLE IF EXISTS `transport`;
CREATE TABLE `transport` (
  `id` int(11) NOT NULL,
  `type` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `route` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `transport`
--

INSERT INTO `transport` (`id`, `type`, `name`, `route`) VALUES
(7, 'bus', '1', '8 микрорайон - 13 микрорайон - 12 микрорайон - Универмаг - ХГУ - Панчшанбе - Сомон бозор'),
(8, 'micro_bus', '28', '8 микрорайон - 13 микрорайон - 12 микрорайон - Универмаг - Ёва'),
(9, 'bus', '5', 'Ёва - Панчшанбе - Сомон бозор'),
(10, 'bus', '3', 'Универмаг - ХГУ - Панчшанбе - 31 микрорайон - Сомон бозор'),
(11, 'bus', 'автобус 4', '8 микрорайон - 13 микрорайон - 12 микрорайон - ХГУ');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `transport`
--
ALTER TABLE `transport`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `route`
--
ALTER TABLE `route`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `transport`
--
ALTER TABLE `transport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
